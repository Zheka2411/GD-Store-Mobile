import React from "react";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { StatusBar } from "expo-status-bar";
import { Text } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { AppProvider, useApp } from "./src/context/AppContext";
import { colors } from "./src/theme";
import CatalogScreen from "./src/screens/CatalogScreen";
import GameScreen from "./src/screens/GameScreen";
import CartScreen from "./src/screens/CartScreen";
import LibraryScreen from "./src/screens/LibraryScreen";
import ProfileScreen from "./src/screens/ProfileScreen";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const theme = {
  ...DarkTheme,
  colors: { ...DarkTheme.colors, background: colors.bg, card: colors.card, primary: colors.accent, text: colors.text, border: colors.border },
};

const icon = (s) => ({ color }) => <Text style={{ fontSize: 18, color }}>{s}</Text>;

function Tabs() {
  const { cart } = useApp();
  return (
    <Tab.Navigator screenOptions={{ tabBarActiveTintColor: colors.accent, tabBarInactiveTintColor: colors.muted }}>
      <Tab.Screen name="Catalog" component={CatalogScreen} options={{ title: "Магазин", tabBarIcon: icon("🎮") }} />
      <Tab.Screen name="Cart" component={CartScreen} options={{ title: "Корзина", tabBarIcon: icon("🛒"), tabBarBadge: cart.length || undefined }} />
      <Tab.Screen name="Library" component={LibraryScreen} options={{ title: "Библиотека", tabBarIcon: icon("📚") }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: "Профиль", tabBarIcon: icon("👤") }} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <NavigationContainer theme={theme}>
          <StatusBar style="light" />
          <Stack.Navigator>
            <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
            <Stack.Screen name="Game" component={GameScreen} options={({ route }) => ({ title: route.params.game.title })} />
          </Stack.Navigator>
        </NavigationContainer>
      </AppProvider>
    </SafeAreaProvider>
  );
}
