# GD Store Mobile (React Native + Expo Go)

Мобильная версия командного проекта GD Store. Работает с тем же Django-сервером (REST API, JWT).

## Возможности
- Каталог игр с сервера (`/api/v1/catalog/games/`), поиск и фильтр по жанрам, обновление свайпом
- Если сервер недоступен — показывается встроенный каталог (GTA V, GTA VI, CS2, Dota 2)
- Страница игры: описание, теги, цена/скидка, добавление в корзину и желаемое
- Корзина и список желаемого сохраняются на телефоне (AsyncStorage)
- Регистрация и вход (`/api/v1/auth/register/`, `/api/v1/auth/login/`), профиль (`/auth/me/`)
- Библиотека купленных игр (`/api/v1/library/`)

## Запуск
1. Установите на телефон **Expo Go** (SDK 54).
2. На компьютере (Node.js 20+):
   ```bash
   npm install
   npx expo install --fix
   npx expo start
   ```
3. Отсканируйте QR-код камерой (iOS) или в Expo Go (Android).

## Подключение к серверу
1. Запустите Django так, чтобы он был доступен в сети:
   ```bash
   python backend/manage.py runserver 0.0.0.0:8000
   ```
   В `backend/.env` добавьте IP компьютера в `ALLOWED_HOSTS` (например `ALLOWED_HOSTS=127.0.0.1,localhost,192.168.0.100`).
2. В `src/config.js` укажите IP компьютера: `http://192.168.0.100:8000/api/v1`.
3. Телефон и компьютер — в одной Wi‑Fi сети.

## Структура
```
App.js                  навигация (вкладки + экран игры)
src/api.js              запросы к серверу, приведение данных
src/config.js           адрес API
src/context/AppContext  авторизация, корзина, желаемое
src/screens/            Каталог, Игра, Корзина, Библиотека, Профиль
```
