import { API_URL } from "./config";
import seed from "./seed.json";

const localArt = {
  "gta-v": require("../assets/art/gta-v.jpg"),
  "gta-vi": require("../assets/art/gta-vi.jpg"),
  cs2: require("../assets/art/cs2.jpg"),
  dota2: require("../assets/art/dota2.jpg"),
};

// Приводим ответ сервера и локальные данные к одному виду
function normalizeServerGame(g) {
  const genres = (g.genres || []).map((x) => x.name);
  return {
    id: String(g.id),
    slug: g.slug,
    title: g.title,
    description: g.description || g.short_description || "",
    tagline: g.short_description || "",
    price: Number(g.price),
    discount: Number(g.discount_percent || 0),
    finalPrice: Number(g.final_price ?? g.price),
    genre: genres[0] || "Игра",
    tags: (g.tags || []).map((t) => t.name),
    image: g.cover_image ? { uri: g.cover_image } : localArt[g.slug] || null,
    releaseDate: g.release_date,
    platforms: g.platforms,
    isPreorder: g.is_preorder,
  };
}

function normalizeSeedGame(g) {
  const finalPrice = Math.round(g.price * (1 - (g.discount || 0) / 100));
  return {
    id: g.id,
    slug: g.id,
    title: g.title,
    description: g.description,
    tagline: g.tagline,
    price: g.price,
    discount: g.discount || 0,
    finalPrice,
    genre: g.genre,
    tags: g.tags || [],
    image: localArt[g.id] || null,
    releaseDate: g.releaseDate,
    platforms: g.platforms,
    isPreorder: g.isPreorder,
  };
}

async function request(path, { method = "GET", body, token } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);
  try {
    const res = await fetch(`${API_URL}${path}`, {
      method,
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    const data = text ? JSON.parse(text) : null;
    if (!res.ok) {
      const msg =
        data?.detail ||
        (data && typeof data === "object"
          ? Object.values(data).flat().join("\n")
          : `Ошибка ${res.status}`);
      throw new Error(msg);
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

// Каталог: сначала сервер, при недоступности — локальные данные
export async function fetchGames(search = "") {
  try {
    const q = search ? `?search=${encodeURIComponent(search)}` : "";
    const data = await request(`/catalog/games/${q}`);
    const list = Array.isArray(data) ? data : data.results || [];
    return { games: list.map(normalizeServerGame), offline: false };
  } catch {
    const s = search.toLowerCase();
    const games = seed
      .map(normalizeSeedGame)
      .filter((g) => !s || g.title.toLowerCase().includes(s));
    return { games, offline: true };
  }
}

export const login = (username, password) =>
  request("/auth/login/", { method: "POST", body: { username, password } });

export const register = (username, email, password) =>
  request("/auth/register/", {
    method: "POST",
    body: { username, email, password },
  });

export const fetchMe = (token) => request("/auth/me/", { token });

export async function fetchLibrary(token) {
  const data = await request("/library/", { token });
  const list = Array.isArray(data) ? data : data.results || [];
  return list.map((e) => ({
    id: String(e.id),
    purchasedAt: e.purchased_at,
    playtime: e.playtime_minutes,
    game: normalizeServerGame(e.game),
  }));
}

export const formatPrice = (n) => (n === 0 ? "Бесплатно" : `${n} ₴`);
