// Адрес Django-сервера GD Store.
// Телефон и компьютер должны быть в одной Wi‑Fi сети.
// Замените IP на IP вашего компьютера (ipconfig / ifconfig),
// а сервер запускайте так: python manage.py runserver 0.0.0.0:8000
export const API_URL = "http://192.168.0.100:8000/api/v1";
