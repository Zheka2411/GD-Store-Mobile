import React, { createContext, useContext, useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as api from "../api";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [ready, setReady] = useState(false);

  // Загрузка сохранённых данных при старте
  useEffect(() => {
    (async () => {
      try {
        const [t, c, w] = await Promise.all([
          AsyncStorage.getItem("token"),
          AsyncStorage.getItem("cart"),
          AsyncStorage.getItem("wishlist"),
        ]);
        if (c) setCart(JSON.parse(c));
        if (w) setWishlist(JSON.parse(w));
        if (t) {
          setToken(t);
          api.fetchMe(t).then(setUser).catch(() => {});
        }
      } finally {
        setReady(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (ready) AsyncStorage.setItem("cart", JSON.stringify(cart));
  }, [cart, ready]);
  useEffect(() => {
    if (ready) AsyncStorage.setItem("wishlist", JSON.stringify(wishlist));
  }, [wishlist, ready]);

  async function signIn(username, password) {
    const data = await api.login(username, password);
    await AsyncStorage.setItem("token", data.access);
    setToken(data.access);
    try {
      setUser(await api.fetchMe(data.access));
    } catch {
      setUser({ username });
    }
  }

  async function signUp(username, email, password) {
    await api.register(username, email, password);
    await signIn(username, password);
  }

  async function signOut() {
    await AsyncStorage.removeItem("token");
    setToken(null);
    setUser(null);
  }

  const inCart = (id) => cart.some((g) => g.id === id);
  const addToCart = (game) => !inCart(game.id) && setCart([...cart, game]);
  const removeFromCart = (id) => setCart(cart.filter((g) => g.id !== id));
  const clearCart = () => setCart([]);

  const inWishlist = (id) => wishlist.some((g) => g.id === id);
  const toggleWishlist = (game) =>
    setWishlist(
      inWishlist(game.id)
        ? wishlist.filter((g) => g.id !== game.id)
        : [...wishlist, game]
    );

  return (
    <AppContext.Provider
      value={{
        ready, token, user, signIn, signUp, signOut,
        cart, inCart, addToCart, removeFromCart, clearCart,
        wishlist, inWishlist, toggleWishlist,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
