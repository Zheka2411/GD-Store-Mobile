import React from "react";
import { View, Text, FlatList, Image, Pressable, StyleSheet, Alert } from "react-native";
import { useApp } from "../context/AppContext";
import { formatPrice } from "../api";
import { colors } from "../theme";

export default function CartScreen({ navigation }) {
  const { cart, removeFromCart, clearCart, user } = useApp();
  const total = cart.reduce((sum, g) => sum + g.finalPrice, 0);

  function checkout() {
    if (!user) {
      Alert.alert("Нужен вход", "Войдите в аккаунт, чтобы оформить заказ.", [
        { text: "Отмена" },
        { text: "Войти", onPress: () => navigation.navigate("Profile") },
      ]);
      return;
    }
    Alert.alert("Учебный заказ", `Сумма: ${formatPrice(total)}. Заказ оформлен (тестовый режим).`);
    clearCart();
  }

  if (!cart.length) {
    return (
      <View style={[s.root, s.center]}>
        <Text style={s.empty}>Корзина пуста</Text>
        <Pressable style={s.btn} onPress={() => navigation.navigate("Catalog")}>
          <Text style={s.btnText}>В магазин</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={s.root}>
      <FlatList
        data={cart} keyExtractor={(g) => g.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        renderItem={({ item }) => (
          <View style={s.row}>
            {item.image && <Image source={item.image} style={s.thumb} />}
            <View style={{ flex: 1 }}>
              <Text style={s.title}>{item.title}</Text>
              <Text style={s.price}>{formatPrice(item.finalPrice)}</Text>
            </View>
            <Pressable onPress={() => removeFromCart(item.id)}><Text style={s.remove}>✕</Text></Pressable>
          </View>
        )}
      />
      <View style={s.footer}>
        <Text style={s.total}>Итого: {formatPrice(total)}</Text>
        <Pressable style={s.btn} onPress={checkout}><Text style={s.btnText}>Оформить</Text></Pressable>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  center: { justifyContent: "center", alignItems: "center", gap: 16 },
  empty: { color: colors.muted, fontSize: 16 },
  row: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.card, padding: 10, borderRadius: 12, borderWidth: 1, borderColor: colors.border },
  thumb: { width: 80, height: 50, borderRadius: 6 },
  title: { color: colors.text, fontWeight: "700" },
  price: { color: colors.accent, marginTop: 2 },
  remove: { color: colors.danger, fontSize: 18, padding: 6 },
  footer: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 16, borderTopWidth: 1, borderColor: colors.border, backgroundColor: colors.card },
  total: { color: colors.text, fontSize: 18, fontWeight: "800" },
  btn: { backgroundColor: colors.accentDark, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10 },
  btnText: { color: colors.text, fontWeight: "700" },
});
