import React, { useCallback, useEffect, useState } from "react";
import { View, Text, TextInput, FlatList, Image, Pressable, StyleSheet, RefreshControl, ActivityIndicator } from "react-native";
import { fetchGames, formatPrice } from "../api";
import { colors } from "../theme";

export default function CatalogScreen({ navigation }) {
  const [games, setGames] = useState([]);
  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("Все");
  const [loading, setLoading] = useState(true);
  const [offline, setOffline] = useState(false);

  const load = useCallback(async (q = search) => {
    setLoading(true);
    const res = await fetchGames(q);
    setGames(res.games);
    setOffline(res.offline);
    setLoading(false);
  }, [search]);

  useEffect(() => {
    const t = setTimeout(() => load(search), 400);
    return () => clearTimeout(t);
  }, [search]);

  const genres = ["Все", ...new Set(games.map((g) => g.genre))];
  const shown = genre === "Все" ? games : games.filter((g) => g.genre === genre);

  return (
    <View style={s.root}>
      <TextInput style={s.search} placeholder="Поиск игр…" placeholderTextColor={colors.muted} value={search} onChangeText={setSearch} />
      {offline && <Text style={s.offline}>Сервер недоступен — показан локальный каталог</Text>}
      <FlatList
        horizontal showsHorizontalScrollIndicator={false} data={genres} keyExtractor={(x) => x}
        style={{ flexGrow: 0, marginBottom: 8 }} contentContainerStyle={{ gap: 8, paddingHorizontal: 16 }}
        renderItem={({ item }) => (
          <Pressable onPress={() => setGenre(item)} style={[s.chip, genre === item && s.chipActive]}>
            <Text style={[s.chipText, genre === item && { color: colors.bg }]}>{item}</Text>
          </Pressable>
        )}
      />
      {loading && !games.length ? <ActivityIndicator color={colors.accent} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={shown} keyExtractor={(g) => g.id}
          contentContainerStyle={{ padding: 16, gap: 14 }}
          refreshControl={<RefreshControl refreshing={loading} onRefresh={() => load()} tintColor={colors.accent} />}
          ListEmptyComponent={<Text style={s.empty}>Ничего не найдено</Text>}
          renderItem={({ item }) => (
            <Pressable style={s.card} onPress={() => navigation.navigate("Game", { game: item })}>
              {item.image ? <Image source={item.image} style={s.img} /> : <View style={[s.img, { backgroundColor: colors.border }]} />}
              <View style={s.info}>
                <Text style={s.title}>{item.title}</Text>
                <Text style={s.genre}>{item.genre}{item.isPreorder ? " · Предзаказ" : ""}</Text>
                <View style={s.priceRow}>
                  {item.discount > 0 && <Text style={s.sale}>-{item.discount}%</Text>}
                  <Text style={s.price}>{formatPrice(item.finalPrice)}</Text>
                </View>
              </View>
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  search: { margin: 16, marginBottom: 10, backgroundColor: colors.card, color: colors.text, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.border },
  offline: { color: colors.sale, marginHorizontal: 16, marginBottom: 8, fontSize: 12 },
  chip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  chipActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  chipText: { color: colors.text },
  card: { backgroundColor: colors.card, borderRadius: 14, overflow: "hidden", borderWidth: 1, borderColor: colors.border },
  img: { width: "100%", height: 170 },
  info: { padding: 12 },
  title: { color: colors.text, fontSize: 17, fontWeight: "700" },
  genre: { color: colors.muted, marginTop: 2 },
  priceRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8 },
  sale: { backgroundColor: colors.sale, color: colors.bg, paddingHorizontal: 6, borderRadius: 4, fontWeight: "700" },
  price: { color: colors.accent, fontWeight: "700", fontSize: 16 },
  empty: { color: colors.muted, textAlign: "center", marginTop: 40 },
});
