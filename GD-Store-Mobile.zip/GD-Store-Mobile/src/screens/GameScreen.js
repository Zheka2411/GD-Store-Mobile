import React from "react";
import { ScrollView, View, Text, Image, Pressable, StyleSheet } from "react-native";
import { useApp } from "../context/AppContext";
import { formatPrice } from "../api";
import { colors } from "../theme";

export default function GameScreen({ route, navigation }) {
  const { game } = route.params;
  const { inCart, addToCart, inWishlist, toggleWishlist } = useApp();
  const added = inCart(game.id);

  return (
    <ScrollView style={s.root} contentContainerStyle={{ paddingBottom: 40 }}>
      {game.image && <Image source={game.image} style={s.img} />}
      <View style={s.body}>
        <Text style={s.title}>{game.title}</Text>
        {!!game.tagline && <Text style={s.tagline}>{game.tagline}</Text>}
        <View style={s.tags}>
          {[game.genre, ...game.tags].map((t) => <Text key={t} style={s.tag}>{t}</Text>)}
        </View>
        <Text style={s.desc}>{game.description}</Text>
        {!!game.platforms && <Text style={s.meta}>Платформы: {game.platforms}</Text>}
        {!!game.releaseDate && <Text style={s.meta}>Дата выхода: {game.releaseDate}</Text>}

        <View style={s.buyBox}>
          <View>
            {game.discount > 0 && <Text style={s.old}>{formatPrice(game.price)}</Text>}
            <Text style={s.price}>{formatPrice(game.finalPrice)}</Text>
          </View>
          <Pressable
            style={[s.btn, added && { backgroundColor: colors.border }]}
            onPress={() => (added ? navigation.navigate("Tabs", { screen: "Cart" }) : addToCart(game))}
          >
            <Text style={s.btnText}>{added ? "В корзине →" : game.isPreorder ? "Предзаказ" : "В корзину"}</Text>
          </Pressable>
        </View>
        <Pressable style={s.wish} onPress={() => toggleWishlist(game)}>
          <Text style={{ color: colors.text }}>{inWishlist(game.id) ? "♥ В списке желаемого" : "♡ Добавить в желаемое"}</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  img: { width: "100%", height: 230 },
  body: { padding: 16 },
  title: { color: colors.text, fontSize: 24, fontWeight: "800" },
  tagline: { color: colors.muted, marginTop: 6, fontStyle: "italic" },
  tags: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginVertical: 12 },
  tag: { color: colors.text, backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, fontSize: 12 },
  desc: { color: colors.text, lineHeight: 21 },
  meta: { color: colors.muted, marginTop: 8 },
  buyBox: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.card, padding: 14, borderRadius: 12, marginTop: 20, borderWidth: 1, borderColor: colors.border },
  old: { color: colors.muted, textDecorationLine: "line-through" },
  price: { color: colors.accent, fontSize: 20, fontWeight: "800" },
  btn: { backgroundColor: colors.accentDark, paddingHorizontal: 18, paddingVertical: 12, borderRadius: 10 },
  btnText: { color: colors.text, fontWeight: "700" },
  wish: { marginTop: 12, padding: 12, alignItems: "center", borderRadius: 10, borderWidth: 1, borderColor: colors.border },
});
