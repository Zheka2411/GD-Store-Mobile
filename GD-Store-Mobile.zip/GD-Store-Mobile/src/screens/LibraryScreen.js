import React, { useCallback, useState } from "react";
import { View, Text, FlatList, Image, StyleSheet, RefreshControl, Pressable } from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { useApp } from "../context/AppContext";
import { fetchLibrary } from "../api";
import { colors } from "../theme";

export default function LibraryScreen({ navigation }) {
  const { token, wishlist } = useApp();
  const [items, setItems] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      setItems(await fetchLibrary(token));
    } catch (e) {
      setError("Не удалось загрузить библиотеку с сервера");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const Card = ({ game, sub }) => (
    <Pressable style={s.row} onPress={() => navigation.navigate("Game", { game })}>
      {game.image && <Image source={game.image} style={s.thumb} />}
      <View style={{ flex: 1 }}>
        <Text style={s.title}>{game.title}</Text>
        <Text style={s.sub}>{sub}</Text>
      </View>
    </Pressable>
  );

  return (
    <FlatList
      style={s.root}
      contentContainerStyle={{ padding: 16, gap: 10 }}
      data={items}
      keyExtractor={(e) => e.id}
      refreshControl={<RefreshControl refreshing={loading} onRefresh={load} tintColor={colors.accent} />}
      ListHeaderComponent={
        <View>
          <Text style={s.h}>Мои игры</Text>
          {!token && <Text style={s.muted}>Войдите во вкладке «Профиль», чтобы увидеть купленные игры.</Text>}
          {error && <Text style={s.err}>{error}</Text>}
          {token && !error && !loading && !items.length && <Text style={s.muted}>Пока нет игр</Text>}
        </View>
      }
      renderItem={({ item }) => (
        <Card game={item.game} sub={`Наиграно: ${Math.round((item.playtime || 0) / 60)} ч`} />
      )}
      ListFooterComponent={
        <View style={{ marginTop: 20, gap: 10 }}>
          <Text style={s.h}>Желаемое ({wishlist.length})</Text>
          {wishlist.map((g) => <Card key={g.id} game={g} sub={g.genre} />)}
        </View>
      }
    />
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  h: { color: colors.text, fontSize: 20, fontWeight: "800", marginBottom: 8 },
  muted: { color: colors.muted },
  err: { color: colors.danger },
  row: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.card, padding: 10, borderRadius: 12, borderWidth: 1, borderColor: colors.border },
  thumb: { width: 80, height: 50, borderRadius: 6 },
  title: { color: colors.text, fontWeight: "700" },
  sub: { color: colors.muted, marginTop: 2 },
});
