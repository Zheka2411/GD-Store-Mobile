import React, { useState } from "react";
import { View, Text, TextInput, Pressable, StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform } from "react-native";
import { useApp } from "../context/AppContext";
import { API_URL } from "../config";
import { colors } from "../theme";

export default function ProfileScreen() {
  const { user, signIn, signUp, signOut, cart, wishlist } = useApp();
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  if (user) {
    return (
      <View style={s.root}>
        <View style={s.avatar}><Text style={s.avatarText}>{user.username?.[0]?.toUpperCase()}</Text></View>
        <Text style={s.name}>{user.username}</Text>
        {!!user.email && <Text style={s.muted}>{user.email}</Text>}
        <View style={s.stats}>
          <Stat label="В корзине" value={cart.length} />
          <Stat label="Желаемое" value={wishlist.length} />
        </View>
        <Pressable style={[s.btn, { backgroundColor: colors.border }]} onPress={signOut}>
          <Text style={s.btnText}>Выйти</Text>
        </Pressable>
      </View>
    );
  }

  async function submit() {
    setError(null);
    if (!username || !password) return setError("Заполните логин и пароль");
    setBusy(true);
    try {
      if (mode === "login") await signIn(username.trim(), password);
      else await signUp(username.trim(), email.trim(), password);
    } catch (e) {
      setError(e.name === "AbortError" ? `Сервер не отвечает (${API_URL})` : e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <KeyboardAvoidingView style={s.root} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <Text style={s.h}>{mode === "login" ? "Вход" : "Регистрация"}</Text>
      <TextInput style={s.input} placeholder="Имя пользователя" placeholderTextColor={colors.muted} autoCapitalize="none" value={username} onChangeText={setUsername} />
      {mode === "register" && (
        <TextInput style={s.input} placeholder="Email" placeholderTextColor={colors.muted} autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
      )}
      <TextInput style={s.input} placeholder="Пароль" placeholderTextColor={colors.muted} secureTextEntry value={password} onChangeText={setPassword} />
      {error && <Text style={s.err}>{error}</Text>}
      <Pressable style={s.btn} onPress={submit} disabled={busy}>
        {busy ? <ActivityIndicator color={colors.text} /> : <Text style={s.btnText}>{mode === "login" ? "Войти" : "Создать аккаунт"}</Text>}
      </Pressable>
      <Pressable onPress={() => setMode(mode === "login" ? "register" : "login")}>
        <Text style={s.link}>{mode === "login" ? "Нет аккаунта? Регистрация" : "Уже есть аккаунт? Войти"}</Text>
      </Pressable>
    </KeyboardAvoidingView>
  );
}

const Stat = ({ label, value }) => (
  <View style={s.stat}><Text style={s.statVal}>{value}</Text><Text style={s.muted}>{label}</Text></View>
);

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, padding: 20, justifyContent: "center", gap: 12 },
  h: { color: colors.text, fontSize: 26, fontWeight: "800", marginBottom: 8 },
  input: { backgroundColor: colors.card, color: colors.text, borderRadius: 10, padding: 14, borderWidth: 1, borderColor: colors.border },
  err: { color: colors.danger },
  btn: { backgroundColor: colors.accentDark, padding: 14, borderRadius: 10, alignItems: "center", marginTop: 6 },
  btnText: { color: colors.text, fontWeight: "700" },
  link: { color: colors.accent, textAlign: "center", marginTop: 8 },
  avatar: { alignSelf: "center", width: 90, height: 90, borderRadius: 45, backgroundColor: colors.accentDark, justifyContent: "center", alignItems: "center" },
  avatarText: { color: colors.text, fontSize: 38, fontWeight: "800" },
  name: { color: colors.text, fontSize: 22, fontWeight: "800", textAlign: "center" },
  muted: { color: colors.muted, textAlign: "center" },
  stats: { flexDirection: "row", gap: 12, marginVertical: 16 },
  stat: { flex: 1, backgroundColor: colors.card, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center" },
  statVal: { color: colors.accent, fontSize: 22, fontWeight: "800" },
});
