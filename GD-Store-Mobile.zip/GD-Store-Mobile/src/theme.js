export const colors = {
  bg: "#0d1117",
  card: "#161b22",
  border: "#262d36",
  text: "#e6edf3",
  muted: "#8b949e",
  accent: "#3fb950",
  accentDark: "#238636",
  danger: "#f85149",
  sale: "#d29922",
};
